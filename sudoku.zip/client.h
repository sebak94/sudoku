#ifndef __CLIENT_H__
#define __CLIENT_H__

int client_run(const char *hostname, const char *service);

#endif
