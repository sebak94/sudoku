#ifndef __SPLIT_H__
#define __SPLIT_H__

char* split(char *s, const char *delim, char **save_ptr);

#endif
